# HTTP Demo para Windows

Projeto independente em C++17 que demonstra recebimento de respostas HTTP via libcurl e simulação offline de três cenários. **Não modifica nem replica o Nevermiss ou sua ativação.**

## Conteúdo
- `main.cpp`: janela Win32, cenários offline e callback de escrita da libcurl que adiciona os bytes recebidos a uma `std::string`.
- `mock_server.py`: servidor HTTP de testes limitado ao endereço local.
- `CMakeLists.txt`: configuração de compilação.

## Compilar no Windows
Requisitos: Visual Studio 2022 com Desktop development with C++, CMake, e vcpkg com libcurl.

No PowerShell, a partir desta pasta (ajuste o caminho de vcpkg):

```powershell
vcpkg install curl:x64-windows
cmake -S . -B build -A x64 -DCMAKE_TOOLCHAIN_FILE="C:/vcpkg/scripts/buildsystems/vcpkg.cmake"
cmake --build build --config Release
```

Executável gerado: `build/Release/HTTPDemo.exe`.

## Testar
1. Execute `HTTPDemo.exe` e pressione um dos três botões **Offline**. Não é necessário servidor.
2. Para testar HTTP, abra um terminal e execute `python mock_server.py`.
3. No programa, deixe `http://127.0.0.1:8765/` e clique **HTTP local** para obter HTTP 200.
4. Altere para `http://127.0.0.1:8765/error` e clique **HTTP local** para obter HTTP 403.
5. Encerre o servidor e teste novamente para visualizar um erro de conexão.

O botão HTTP aceita apenas URLs de loopback HTTP (`localhost` e `127.0.0.1`). A requisição é síncrona, por simplicidade didática; a janela pode ficar sem responder durante o timeout (até 8 segundos).

## Observações
O sucesso HTTP indica apenas status 2xx, **não** aprovação de licença. As respostas são dados fictícios de laboratório. Não há armazenamento de chaves, modificação de processos ou interceptação de programas de terceiros.
