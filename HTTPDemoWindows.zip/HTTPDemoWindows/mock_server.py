"""Servidor local de demonstração. Não replica nenhum serviço de terceiros."""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/error':
            code, payload = 403, {'status': 'error', 'message': 'Solicitacao rejeitada'}
        else:
            code, payload = 200, {'status': 'ok', 'message': 'Resposta do servidor local'}
        body = json.dumps(payload).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

if __name__ == '__main__':
    print('Servidor em http://127.0.0.1:8765/ (Ctrl+C para parar)')
    HTTPServer(('127.0.0.1', 8765), Handler).serve_forever()
