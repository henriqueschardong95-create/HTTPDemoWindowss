#define UNICODE
#define _UNICODE
#include <windows.h>
#include <curl/curl.h>
#include <string>
#include <sstream>
#include <algorithm>

static HWND g_url{}, g_result{}, g_status{};
static constexpr int ID_OFFLINE_OK=101, ID_OFFLINE_FAIL=102, ID_OFFLINE_DOWN=103, ID_HTTP=104;

struct Response { long status=0; std::string body; std::string error; };
static size_t write_callback(char* ptr,size_t size,size_t nmemb,void* userdata) {
    const size_t bytes=size*nmemb;
    static_cast<std::string*>(userdata)->append(ptr,bytes);
    return bytes;
}
static Response offline(int scenario) {
    if (scenario==ID_OFFLINE_OK) return {200,R"({"status":"ok","mode":"offline","message":"Simulacao concluida"})",{}};
    if (scenario==ID_OFFLINE_FAIL) return {403,R"({"status":"error","mode":"offline","message":"Solicitacao rejeitada"})",{}};
    return {0,{},"Servidor indisponivel (simulacao)"};
}
static Response request(const std::string& url) {
    Response r;
    CURL* curl=curl_easy_init();
    if(!curl) {r.error="Falha ao inicializar libcurl";return r;}
    curl_easy_setopt(curl,CURLOPT_URL,url.c_str());
    curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,write_callback);
    curl_easy_setopt(curl,CURLOPT_WRITEDATA,&r.body);
    curl_easy_setopt(curl,CURLOPT_TIMEOUT,8L);
    curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,3L);
    curl_easy_setopt(curl,CURLOPT_FOLLOWLOCATION,0L);
    curl_easy_setopt(curl,CURLOPT_SSL_VERIFYPEER,1L);
    curl_easy_setopt(curl,CURLOPT_SSL_VERIFYHOST,2L);
    const CURLcode code=curl_easy_perform(curl);
    if(code!=CURLE_OK) r.error=curl_easy_strerror(code);
    curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&r.status);
    curl_easy_cleanup(curl);
    return r;
}
static std::wstring widen(const std::string& s) {
    if(s.empty())return {};
    int count=MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0);
    if(count<=0)return L"[Texto nao UTF-8]";
    std::wstring out(count,L'\0');
    MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),out.data(),count);
    return out;
}
static std::string narrow(const std::wstring& s) {
    if(s.empty())return {};
    int count=WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0,nullptr,nullptr);
    std::string out(count,'\0');
    WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),out.data(),count,nullptr,nullptr);
    return out;
}
static void show_response(const Response& r) {
    std::ostringstream os;
    os << "HTTP: " << r.status << "\r\n";
    if(!r.error.empty()) os << "Erro: " << r.error << "\r\n";
    os << "\r\nCorpo da resposta:\r\n" << r.body;
    SetWindowTextW(g_result,widen(os.str()).c_str());
    const wchar_t* status = !r.error.empty()?L"Falha de comunicacao":(r.status>=200 && r.status<300?L"Sucesso HTTP":L"Resposta HTTP nao bem-sucedida");
    SetWindowTextW(g_status,status);
}
static HWND control(HWND parent,const wchar_t* cls,const wchar_t* title,DWORD style,int x,int y,int w,int h,int id=0) {
    return CreateWindowExW(0,cls,title,WS_CHILD|WS_VISIBLE|style,x,y,w,h,parent,(HMENU)(INT_PTR)id,GetModuleHandleW(nullptr),nullptr);
}
static LRESULT CALLBACK wndproc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp) {
    switch(msg) {
        case WM_CREATE: {
            control(hwnd,L"STATIC",L"Laboratorio de respostas HTTP - projeto independente",0,18,14,630,24);
            control(hwnd,L"STATIC",L"URL de teste (somente localhost):",0,18,51,350,20);
            g_url=control(hwnd,L"EDIT",L"http://127.0.0.1:8765/",WS_BORDER|ES_AUTOHSCROLL,18,75,610,26);
            control(hwnd,L"BUTTON",L"Offline: sucesso",BS_PUSHBUTTON,18,118,145,32,ID_OFFLINE_OK);
            control(hwnd,L"BUTTON",L"Offline: erro",BS_PUSHBUTTON,172,118,145,32,ID_OFFLINE_FAIL);
            control(hwnd,L"BUTTON",L"Offline: sem servidor",BS_PUSHBUTTON,326,118,170,32,ID_OFFLINE_DOWN);
            control(hwnd,L"BUTTON",L"HTTP local",BS_PUSHBUTTON,505,118,123,32,ID_HTTP);
            g_status=control(hwnd,L"STATIC",L"Pronto",0,18,166,610,24);
            g_result=control(hwnd,L"EDIT",L"Selecione um cenario para iniciar.",WS_BORDER|ES_MULTILINE|ES_AUTOVSCROLL|WS_VSCROLL|ES_READONLY,18,194,610,258);
            return 0;
        }
        case WM_COMMAND: {
            int id=LOWORD(wp);
            if(id==ID_OFFLINE_OK || id==ID_OFFLINE_FAIL || id==ID_OFFLINE_DOWN) show_response(offline(id));
            if(id==ID_HTTP) {
                wchar_t buf[2048]{}; GetWindowTextW(g_url,buf,2048);
                std::string url=narrow(buf);
                // Limit HTTP demonstration to loopback to avoid using this tool against third-party services.
                const bool allowed = url.rfind("http://127.0.0.1:",0)==0 || url=="http://127.0.0.1/" || url.rfind("http://localhost:",0)==0 || url=="http://localhost/";
                if(!allowed) {show_response({0,{},"Somente enderecos HTTP localhost sao permitidos"});break;}
                SetWindowTextW(g_status,L"Consultando servidor local...");
                show_response(request(url));
            }
            return 0;
        }
        case WM_DESTROY: PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int show) {
    curl_global_init(CURL_GLOBAL_DEFAULT);
    const wchar_t* cls=L"HTTPDemoWinClass";
    WNDCLASSW wc{};wc.lpfnWndProc=wndproc;wc.hInstance=instance;wc.lpszClassName=cls;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
    if(!RegisterClassW(&wc))return 1;
    HWND hwnd=CreateWindowExW(0,cls,L"HTTP Demo - Offline e Local",WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_THICKFRAME,CW_USEDEFAULT,CW_USEDEFAULT,665,510,nullptr,nullptr,instance,nullptr);
    if(!hwnd)return 2;
    ShowWindow(hwnd,show);UpdateWindow(hwnd);
    MSG msg{};while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}
    curl_global_cleanup();return (int)msg.wParam;
}
